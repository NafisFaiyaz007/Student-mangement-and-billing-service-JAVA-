
public class BDTaxCalculator {
	public double calculateVatAmount(int total) {
		return total * 0.15;
		/*
		 * It will return the tax amount calculated for a specific student. BD Tax =
		 * Course Fees * 0.15 which is 15% of the total course fees.
		 */
	}
}
