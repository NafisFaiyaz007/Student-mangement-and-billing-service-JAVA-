
public interface IExtraFeeCalculator {
	public abstract int getExtraAmount(int courseTotal);
}
