
public interface IDiscountStrategy {
	public abstract int getTotal(Registration reg);
}
